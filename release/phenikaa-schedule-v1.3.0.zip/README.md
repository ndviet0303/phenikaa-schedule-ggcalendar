# Schedule Dispatcher · Phenikaa

Extension tùy biến lịch học cổng đào tạo Phenikaa, phong cách tối giản cao cấp.

- **Tác giả:** [ziet.dev](https://ziet.dev)
- **Facebook:** [fb.com/ziet.cute](https://fb.com/ziet.cute)

---

## 1. Tính năng nổi bật
* **Bảng màu:** Obsidian Dark (`#141113`, `#1e191c`) kết hợp Champagne Gold (`#d8b46e`, `#c9a15a`).
* **Nút bấm & Chip:** Chuẩn pill rounded (`border-radius: 9999px`) với gradient gold.
* **100% Vector SVG:** Không dùng emoji hay icon AI, tất cả icon đều là SVG chuẩn.
* **Liên kết tác giả:** Tích hợp trực tiếp liên kết website `ziet.dev` và Facebook `fb.com/ziet.cute` ở cả Popup và Dock Widget.

---

## 2. Cách cập nhật tiện ích:
1. Vào `edge://extensions/` (hoặc `chrome://extensions/`).
2. Bấm nút **Reload 🔄** tại tiện ích **Phenikaa Schedule Controller**.
3. Tải lại trang portal và tận hưởng!
